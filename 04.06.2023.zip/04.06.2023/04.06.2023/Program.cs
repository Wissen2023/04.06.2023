﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _04._06._2023
{
    public class Program
    {
        //Geriye Değer döndürmeyen ve Parametre Almayan Method
        //public static void Method1()
        //{
        //    Console.WriteLine("Alan: " + (3 * 5));
        //    Console.ReadLine();
        //}


        //Geriye Değer Döndürmeyen ve Parametre Alan
        //public static void Method2(double kısaKenar, double uzunKenar)
        //{
        //    Console.WriteLine("Alan: " + (kısaKenar * uzunKenar));
        //    Console.ReadLine();
        //}


        //Geriye Değer Döndüren ve Parametre Almayan
        //public static double Method3()
        //{
        //    Console.Write("Kısa Kenar Girin: ");
        //    double kısaKenar = Convert.ToDouble(Console.ReadLine());

        //    Console.Write("Uzun Kenar Girin: ");
        //    double uzunKenar = Convert.ToDouble(Console.ReadLine());

        //    double alan = kısaKenar * uzunKenar;

        //    Console.WriteLine("Alan: " + alan);
        //    Console.ReadLine();
        //    return alan;
        //}


        //Geriye Değer Döndüren ve Parametre Alan
        //public static double Method4(double kısaKenar, double uzunKenar)
        //{
        //    double alan = kısaKenar * uzunKenar;
        //    Console.WriteLine("Alan: " + alan);
        //    Console.ReadLine();
        //    return alan;
        //}

        //Geriye değer döndürmeyen ve string türünde parametre alan bir method yazalım. Bu string türündeki metin değerini bize 10 kere bastırsın.
        //public static void Metin(string metin)
        //{
        //    for (int i = 0; i < 10; i++)
        //    {
        //        Console.WriteLine(metin);
        //    }
        //}



        static void Main(string[] args)
        {
            //Console.Write("Bir Metin Girin: ");
            //string mtn = Console.ReadLine();
            //Metin(mtn);
            //Console.ReadLine();

            //Method1();
            //Method2(3, 5);
            //Method3();
            //Method4(3, 5);





            //1. Sorunun Cevabı
            //Console.Write("1. Sınav Notunu Girin: ");
            //double not1 = Convert.ToDouble(Console.ReadLine());

            //Console.Write("2. Sınav Notunu Girin: ");
            //double not2 = Convert.ToDouble(Console.ReadLine());

            //Console.Write("2. Sınav Notunu Girin: ");
            //double not3 = Convert.ToDouble(Console.ReadLine());

            //double ortalama = ((not1 + not2 + not3) / 3);

            //if (ortalama>=50)
            //{
            //    Console.WriteLine("Dersi Geçtiniz ");
            //}
            //else
            //{
            //    Console.WriteLine("Dersi Geçemediniz ");
            //}


            //2. Sorunun Cevabı
            //Console.Write("Kısa Kenarı Girin: ");
            //double kısaKenar = Convert.ToDouble(Console.ReadLine());

            //Console.Write("Uzun Kenarı Girin: ");
            //double uzunKenar = Convert.ToDouble(Console.ReadLine());

            //double alan = uzunKenar * kısaKenar;
            //double cevre = (2 * (uzunKenar + kısaKenar)); 

            //Console.WriteLine("Alan: " + alan);
            //Console.WriteLine("Çevre: " + cevre);



            //3. Sorunun cevbı
            //Console.Write("Yarıçapı girin: ");
            //double yarıcap = Convert.ToDouble(Console.ReadLine());
            //double alan = ((Math.PI) * yarıcap * yarıcap);
            //double cevre = (2 * (Math.PI) * yarıcap);
            //Console.WriteLine("Alan:" + alan);
            //Console.WriteLine("Çevre:" + cevre);

            //4. Sorunun cevabı
            //Console.Write("Bir sayı giriniz: ");
            //int sayi = Convert.ToInt32(Console.ReadLine());

            //if (sayi % 2 == 0)
            //{
            //    Console.WriteLine(sayi + " Sayısı çifttir.");
            //}
            //else
            //{
            //    Console.WriteLine(sayi + " Sayısı tektir.");
            //}



            //5. Sorunun cevabı 
            //Console.Write("1. sayıyı girin: ");
            //double sayi1 = Convert.ToDouble(Console.ReadLine());
            //Console.Write("2. sayıyı girin: ");
            //double sayi2 = Convert.ToDouble(Console.ReadLine());
            //if (sayi1 > sayi2)
            //{
            //    Console.WriteLine(sayi1 + " sayısı büyüktür: ");
            //}
            //else if(sayi1 == sayi2)
            //{
            //    Console.WriteLine("Sayılar eşittir.");
            //}
            //else
            //{
            //    Console.WriteLine(sayi2 + " sayısı büyüktür.");
            //}

            //6. sorunun cevabı
            //Console.Write("Bir sayı girin: ");
            //int sayi = Convert.ToInt32(Console.ReadLine());

            //if (sayi % 4 == 0 && sayi % 7 == 0)
            //{
            //    Console.WriteLine(sayi + " sayısı 4 ile 7 ye tam bölünür.");
            //}
            //else
            //{
            //    Console.WriteLine(sayi + " sayısı 4 ile 7 ye tam bölünmez.");
            //}



            //7. sorunun cevabı
            //Console.Write("Bir sayı girin: ");
            //int sayi = Convert.ToInt32(Console.ReadLine());
            //for (int i = 1; i <= sayi; i++)
            //{
            //    Console.WriteLine(i);
            //}

            //8. sorunun cevabı 
            //double[] dizi = new double[2];
            //for (int i = 0; i < dizi.Length; i++)
            //{
            //    Console.Write((i + 1) + " .elemanı girin: ");
            //    dizi[i] = Convert.ToDouble(Console.ReadLine());
            //}
            //Console.WriteLine("Yeni dizi");
            //for (int i = 0; i < dizi.Length; i++)
            //{
            //    dizi[i] = dizi[i] + ((dizi[i] * 20) / 100);
            //    Console.WriteLine((i + 1) + " . elemean: " + dizi[i]);
            //}

            //9. sorunun cevabı 
            //Console.Write("Bir metin girin: ");
            //string metin = Console.ReadLine();
            //int sayac = 0;
            //for (int i = 0; i < metin.Length; i++)
            //{
            //    if (metin[i] == 'a')
            //    {
            //        sayac++;
            //    }
            //}
            //Console.WriteLine("Metin içindeki 0 sayısı: " + sayac);

            //10. sorunun cevabı 
            //for (int i = 1; i < 50; i++)
            //{
            //    if (i % 2 == 1)
            //    {
            //        Console.WriteLine(i + " sayısının karesi: " + (i * i));
            //    }
            //    else
            //    {
            //        Console.WriteLine(i + " sayısının kübü: " + (i * i * i));
            //    }
            //}



            //11. sorunun cevabı
            //for (int i = 1; i < 100; i++)
            //{
            //    if (i % 3 == 0)
            //    {
            //        Console.WriteLine("3 e bölünebilen sayı: " + i);
            //    }
            //}
        }
    }
}
